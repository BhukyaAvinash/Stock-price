make
./StarPlat -s -f ../graphcode/staticDSLCodes/PageRankDSLV2 -b multigpu