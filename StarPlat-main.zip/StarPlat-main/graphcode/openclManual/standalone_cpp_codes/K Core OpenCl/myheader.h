#ifndef myheader_h
#define myheader_h


#include "graph.hpp"
#include <CL/cl.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include "GraphParse.cpp"
// #include "Akpush_relabel.cpp"
//#include "Akpush_relabel_kernel.cl"


#define INF 1000000000

#endif
