References for the algorithms

1)  For MST
Paper name - A Generic and Highly Efficient Parallel Variant of Borůvka’s Algorithm
   Authors - Cristiano da Silva Sousa, Artur Mariano, Alberto Proença

2) For SCC
Paper name - GPU Centric Extensions for Parallel Strongly Connected Components Computation
Authors - Shrinivas Devshatwar, Madhur Amilkanthwar, Rupesh Nasre

3) For Bipartite Matching
Paper name - Multithreaded Algorithms for Maximum Matching in Bipartite Graphs
Authors - Ariful Azad , Mahantesh Halappanavar , Sivasankaran Rajamanickam , Erik G. Boman ,
           Arif Khan , and Alex Pothen

