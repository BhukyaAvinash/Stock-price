#ifndef GENCPP_REDUCTION_H
#define GENCPP_REDUCTION_H
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <CL/cl.h>
#include "../graph.hpp"

void reductionExample(graph& g);

#endif
