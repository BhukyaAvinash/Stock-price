#ifndef GENCPP_TEMP_ALGO_H
#define GENCPP_TEMP_ALGO_H
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include<atomic>
#include<omp.h>
#include"../graph.hpp"
#include"../atomicUtil.h"

void count_nodes(graph& g);

#endif
