#ifndef GENCPP_V_COVER_H
#define GENCPP_V_COVER_H
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include<atomic>
#include<omp.h>
#include"../graph.hpp"
#include"../atomicUtil.h"

void v_cover(graph& g);

#endif
