#ifndef GENCPP_INPUT2_H
#define GENCPP_INPUT2_H
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include<atomic>
#include<omp.h>
#include"../graph.hpp"

void test(graph& g,int src);

#endif
