#ifndef GENCPP_INPUT4_H
#define GENCPP_INPUT4_H
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include<atomic>
#include<omp.h>
#include"../graph.hpp"

void test(graph& g);

#endif
