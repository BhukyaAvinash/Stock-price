#ifndef GENCPP_TEST1_H
#define GENCPP_TEST1_H
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include"../graph.hpp"

void test1(graph& gg);

#endif
