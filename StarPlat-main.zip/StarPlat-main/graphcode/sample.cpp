#include <string>
#include <stdio.h>
#include <iostream>

using namespace std;

int main()
{
    int a=6;
    int a=5;

    return 0;
}